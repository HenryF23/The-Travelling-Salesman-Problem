Before you run the program, make sure you have installed the following library
1. numpy
2. matplotlib.pyplot

Also, make sure that you are in the correct directory and files "cities1000.txt" is in that directory.

To run the program, type python3 project.py

You will then see the scores and followed with the corresponding permutation. You will then be able to track the progress. Also, in the end, it will show a graph about the performance and time used to run this algorithm.